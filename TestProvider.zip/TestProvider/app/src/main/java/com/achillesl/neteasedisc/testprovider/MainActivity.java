package com.achillesl.neteasedisc.testprovider;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.achillesl.neteasedisc.testprovider.R;

public class MainActivity extends AppCompatActivity {
    private String newId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button queryData=(Button)findViewById(R.id.query_data);
        queryData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("content://com.study.electronic_dictionary/dict/");
                Cursor cursor=getContentResolver().query(uri,null,null,null,null);
                if (cursor!=null){
                    while (cursor.moveToNext()){
                        String word =cursor.getString(cursor.getColumnIndex("word"));
                        String pse=cursor.getString(cursor.getColumnIndex("pse"));
                        String prone=cursor.getString(cursor.getColumnIndex("prone"));
                        String psa=cursor.getString(cursor.getColumnIndex("psa"));
                        String prona=cursor.getString(cursor.getColumnIndex("prona"));
                        String interpret=cursor.getString(cursor.getColumnIndex("interpret"));
                        String sentorig=cursor.getString(cursor.getColumnIndex("sentorig"));
                        String senttrans=cursor.getString(cursor.getColumnIndex("senttrans"));
                        Log.d("MainActivity","单词："+word);
                        Log.d("MainActivity","美音音标："+pse);
                        Log.d("MainActivity","美声："+prone);
                        Log.d("MainActivity","英音音标："+psa);
                        Log.d("MainActivity","英声："+prona);
                        Log.d("MainActivity","释义："+interpret);
                        Log.d("MainActivity","例句："+sentorig);
                        Log.d("MainActivity","psa："+psa);
                        Log.d("MainActivity","下一个词语：");
                    }
                    cursor.close();
                }
            }
        });

    }
}
